# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 16:43:37 2019

@author: vandenbekerom.1
"""

import numpy as np
import matplotlib.pyplot as plt
import fss
from tempfile import TemporaryFile

HT_folder = '../../HITEMP/'

t0 = fss.timer()
try:
    data = np.load('CO2_hitemp.npy')
except(FileNotFoundError):
    data = fss.load_HITRAN([HT_folder + '02_2000-2125_HITEMP2010.par',
                            HT_folder + '02_2125-2250_HITEMP2010.par',
                            HT_folder + '02_2250-2500_HITEMP2010.par'])
    print("Saving database as numpy file...")
    np.save('CO2_hitemp.npy',data)
t0 = fss.timer() - t0
print('Import database: {:.6f}s'.format(t0))
print('{:d} Lines loaded\n'.format(len(data[0])))

T = 4000.0 #K
p =    0.1 #bar

t1 = fss.timer() 
v_dat,I_dat,wL_dat,wG_dat = fss.calc_lines(p,T,data)
N = len(v_dat)
v_dat  = v_dat [:N]
I_dat  = I_dat [:N]
wL_dat = wL_dat[:N]
wG_dat = wG_dat[:N]
t1 = fss.timer() - t1
print('Line calculations: {:.6f}s\n'.format(t1))

dv = 0.002
v  = np.arange(1995,2405,dv)

t2 = fss.timer()
Idlm,DLM = fss.spectrum(v,v_dat,I_dat,wL_dat,wG_dat,res_L=0.01,res_G=0.01,ext='full')
Idlm /= dv
t2 = fss.timer() - t2
print('DLM  total: {:.6f}s'.format(t2))

t3 = fss.timer()
Iref= np.zeros(len(v))
##  comment out for comparison, warning: SLOW! (1571 sec)
##    for v0,I0,wL0,wG0,i in zip(v_dat,I_dat,wL_dat,wG_dat,np.arange(len(v_dat))):
##        #Iref += I0*gV(v,v0,wL0,wG0)
##        Iref += I0 * np.convolve(fss.gL(v,v0,wL0),fss.gG(v,0.5*(v[0]+v[-1])-0.5*dv,wG0)*dv,'same')  
##        print(i)
t3 = fss.timer() - t3
print('Ref. total: {:.6f}s'.format(t3))

plt.plot(v,Idlm,'-')
plt.plot(v,Iref,'k--',label = 'Iref',lw=1)
plt.xlim(2400,2000)
plt.show()


