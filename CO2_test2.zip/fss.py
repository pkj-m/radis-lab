# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 16:43:37 2019

@author: vandenbekerom.1
"""

import numpy as np
import time
from scipy.constants import h,c,k,N_A,pi
import sys
c_cm = 100*c
timer = (time.clock if sys.version_info[0] < 3 else time.perf_counter)


def import_hitran(fnames):
    iso,v0,A21,gs,El,na,da,gu = [],[],[],[],[],[],[],[]
    
    fnames = ([fnames] if type(fnames) == str else sorted(fnames))
    
    for fname in fnames:
        print("Loading " + fname + "...")
        with open(fname,'r') as f:
            for line in f:
                iso.append(  int(line[  2:  3])) #iso
                v0 .append(float(line[  3: 15])) #v0
                A21.append(float(line[ 25: 35])) #A21
                gs .append(float(line[ 40: 45])) #gamma_self
                El .append(float(line[ 45: 55])) #Elow
                na .append(float(line[ 55: 59])) #n_air
                da .append(float(line[ 59: 67])) #d_air
                gu .append(float(line[146:153])) #g_up
            
    return np.array([iso,v0,A21,gs,El,na,da,gu])
    
def load_HITRAN(fname):
    data = import_hitran(fname)
    data = data[:,data[0]<=3] # select only first three isotopes
    iso,v0,A21,gs,El,na,da,gu = data
    
    Mm   = (np.array([44,45,46])* 1e-3 / N_A)[iso.astype(int)-1]
    f_ab = np.array([ 0.98420, 0.01106, 0.0039471])[iso.astype(int)-1]
    Eu   = El + v0
    S0 = f_ab * gu * A21 / (8*pi*c_cm*v0**2)
                                         
    return np.array([v0,da,S0,El,Eu,gs,na,Mm])

def calc_lines(p,T,data):
    v0,da,S0,El,Eu,gs,na,Mm = data
    v_dat  = v0 + p*da
    I_dat  = S0 * (np.exp(-h*c_cm*El/(k*T)) - np.exp(-h*c_cm*Eu/(k*T)))
    wL_dat = 2*gs*p*(296/T)**na
    wG_dat = 2*v_dat*np.sqrt(2*k*T*np.log(2)/(c**2 * Mm))
    
    return (v_dat,I_dat,wL_dat,wG_dat)
    
def gL(v,v0,w):
    return (1/np.pi) * (w/2) / ((v-v0)**2 + (w/2)**2)

def gG(v,v0,w):
    return (2/w)*np.sqrt(np.log(2)/np.pi)*np.exp(-4*np.log(2)*((v-v0)/w)**2)
 
def gV(v,v0,wL,wG):
    gamma = (wG**5 + 2.69269*wG**4*wL + 2.42843*wG**3*wL**2 + 4.47163*wG**2*wL**3 + 0.07842*wG*wL**4 + wL**5)**0.2
    eta   = 1.36603*wL/gamma - 0.47719*(wL/gamma)**2 + 0.11116*(wG/gamma)**3
    return (1-eta) * gG(v,v0,gamma) + eta * gL(v,v0,gamma)

def gL_FT(x,w):
    # FT of (1/np.pi) * (w/2) / ((v-v0)**2 + (w/2)**2)*dv
    n = len(x)
    I = np.zeros(n)
    I[:n//2+n%2] = np.exp(-np.pi*x[:n//2+n%2]*w)
    I[-(n//2): ] = I[n//2:0:-1]
    return I

def gG_FT(x,w):
    # FT of (2/w)*np.sqrt(np.log(2)/np.pi)*np.exp(-4*np.log(2)*((v-v0)/w)**2)*dv
    n = len(x)
    I = np.zeros(n)
    I[:n//2+n%2] = np.exp(-(np.pi*x[:n//2+n%2]*w)**2/(4*np.log(2)))
    I[-(n//2): ] = I[n//2:0:-1]
    return I

def lorentzian_step(res_L):
    return (res_L/0.20)**0.5

def gaussian_step(res_G):
    return (res_G/0.46)**0.5

def init_w_axis(w_dat,w_step):
    f = 1 + w_step
    N = max(1,int(np.log(max(w_dat) / min(w_dat))/np.log(f))+1)+1
    return min(w_dat) * f ** np.arange(N)

def init_map(v,wL,wG,v_dat,I_dat,wL_dat,wG_dat,ext = 'full',verbose = 0):

    if ext == 'full':
        ext = len(v)
    elif ext == 'same' or ext == None:
        ext = 0
    
    ## Initialize DLM:
    DLM = np.zeros((len(v)+ext,len(wL),len(wG)))

    #First we calculate the fractional index of the DLM 
    #that corresponds with this line:
    t1 = timer() 
    iv  = np.interp(v_dat, v, np.arange(len(v ))) + ext//2
    iwL = np.interp(wL_dat,wL,np.arange(len(wL)))
    iwG = np.interp(wG_dat,wG,np.arange(len(wG)))
    t1 = timer() - t1
        
    #The actual indices will be the integer numbers just
    #above and just below it:
    t2 = timer()
    iv0  = iv .astype(int)
    iwL0 = iwL.astype(int)
    iwG0 = iwG.astype(int)
        
    iv1  = iv0  + 1
    iwL1 = iwL0 + 1
    iwG1 = iwG0 + 1
    t2 = timer() - t2
    
    #Next calculate how the line is distributed over
    #the 2x2x2 bins we have:
    t3 = timer()
    av  =  iv  - iv0
    awL = (iwL - iwL0) * (wL[iwL1] / wL_dat)
    awG = (iwG - iwG0) * (wG[iwG1] / wG_dat) 
    
    awV00 = (1-awL) * (1-awG)
    awV10 =    awL  * (1-awG)
    awV01 = (1-awL) *    awG
    awV11 =    awL  *    awG
    
    Iv0 = I_dat * (1-av)
    Iv1 = I_dat *    av
    t3 = timer() - t3
    
    t4 = timer()
    np.add.at(DLM,(iv0,iwL0,iwG0),Iv0*awV00)
    np.add.at(DLM,(iv1,iwL0,iwG0),Iv1*awV00)
    np.add.at(DLM,(iv0,iwL1,iwG0),Iv0*awV10)
    np.add.at(DLM,(iv1,iwL1,iwG0),Iv1*awV10)
    np.add.at(DLM,(iv0,iwL0,iwG1),Iv0*awV01)
    np.add.at(DLM,(iv1,iwL0,iwG1),Iv1*awV01)
    np.add.at(DLM,(iv0,iwL1,iwG1),Iv0*awV11)
    np.add.at(DLM,(iv1,iwL1,iwG1),Iv1*awV11)
    t4 = timer() - t4
    
    if verbose > 0:
        print("DLM->index:      {:.6f}s".format(t1))
        print("DLM->rounding:   {:.6f}s".format(t2))
        print("DLM->distribute: {:.6f}s".format(t3))
        print("DLM->populate:   {:.6f}s".format(t4))
        print("")
    
    return DLM

def init_FT_lineshapes(v,wL,wG,ext = 'full'):
    if ext == 'full':
        ext = len(v)
    elif ext == 'same' or ext == None:
        ext = 0
        
    dv = np.mean(v[1:]-v[:-1])
    x  = np.arange(len(v)+ext) / ((len(v)+ext)*dv)
    IL_FT = [gL_FT(x,wL[i]) for i in range(len(wL))]
    IG_FT = [gG_FT(x,wG[j]) for j in range(len(wG))]
    return IL_FT,IG_FT

def synthesize_spectrum(DLM,IL_FT,IG_FT):
    Idlm_FT = 1j*np.zeros(DLM.shape[0])
    for i in range(DLM.shape[1]):
        for j in range(DLM.shape[2]):
            Idlm_FT += np.fft.fft(np.fft.fftshift(DLM[:,i,j])) * IL_FT[i] * IG_FT[j]
    
    return np.fft.ifftshift(np.fft.ifft(Idlm_FT).real)

def spectrum(v,v_dat,I_dat,wL_dat,wG_dat,
             res_L = 0.01,
             res_G = 0.01,
             ext = 'full',
             verbose = 1):

    if ext == 'full':
        ext = len(v)
    elif ext == 'same' or ext == None:
        ext = 0
    
    wL_step = lorentzian_step(res_L)
    wG_step = gaussian_step(res_G)
    
    wL = init_w_axis(wL_dat,wL_step)
    wG = init_w_axis(wG_dat,wG_step)
    
    if verbose > 0:
        print("{:2d} Lorentzians (Step: {:2.0f}%)".format(len(wL),wL_step*100))
        print("{:2d} Gaussians   (Step: {:2.0f}%)".format(len(wG),wG_step*100))
        print("{:2d} FFT's".format(len(wL)*len(wG)+1))
        print("")
        
    t1 = timer()
    IL_FT,IG_FT = init_FT_lineshapes(v,wL,wG,ext = ext)
    t1 = timer() - t1
    
    t2 = timer()
    DLM = init_map(v,wL,wG,v_dat,I_dat,wL_dat,wG_dat,ext = ext,verbose = verbose)
    t2 = timer() - t2

    t3 = timer()
    I = synthesize_spectrum(DLM,IL_FT,IG_FT)
    t3 = timer() - t3
    
    tt = t1 + t2 + t3
    
    if verbose > 0:
        print("Lineshapes: {:.6f}s ({:.1f}%)".format(t1,100*t1/tt))
        print("DLM:        {:.6f}s ({:.1f}%)".format(t2,100*t2/tt))
        print("FFT:        {:.6f}s ({:.1f}%)".format(t3,100*t3/tt))
        print("")
        
    return I[ext//2:ext//2+len(v)],DLM


